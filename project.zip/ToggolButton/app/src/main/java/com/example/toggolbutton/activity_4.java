package com.example.toggolbutton;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

public class activity_4 extends AppCompatActivity {
    Button NextButton3;
     CheckBox checkBox1;
     CheckBox checkBox2;
     CheckBox checkBox3;
     CheckBox checkBox4;
     CheckBox checkBox5;
     CheckBox checkBox6;
     CheckBox checkBox7;
     CheckBox checkBox8;

     @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_4);
        NextButton3 = findViewById(R.id.nextButton3);
        checkBox1=findViewById(R.id.check1);
        checkBox2=findViewById(R.id.check2);
        checkBox3=findViewById(R.id.check3);
        checkBox4=findViewById(R.id.check4);
        checkBox5=findViewById(R.id.check5);
        checkBox6=findViewById(R.id.check6);
        checkBox7=findViewById(R.id.check7);
        checkBox8=findViewById(R.id.check8);
    }

    public void onclick4(View view){
        Intent nextButton3=new Intent(this,activity_5.class);
        startActivity(nextButton3);
    }
}