package com.example.toggolbutton;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class activity_2 extends AppCompatActivity {
    Button NextButton1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activety_2);
        NextButton1 = (Button) findViewById(R.id.nextButton1);
    }

    public void onclick2(View view) {
        Intent nextButton1 = new Intent(this, activity_3.class);
        startActivity(nextButton1);
    }


}