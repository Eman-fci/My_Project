package com.example.toggolbutton;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;

public class activity_5 extends AppCompatActivity {
    Button NextButton4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_5);

         NextButton4 = findViewById(R.id.nextButton4);
    }
     public void onclick5(View view){
         Intent nextButton4=new Intent(this,MainActivity.class);
          startActivity(nextButton4);

     }

}