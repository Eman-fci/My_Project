package com.example.toggolbutton;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class activity_3 extends AppCompatActivity {
    Button NextButton2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);
        NextButton2 = (Button)findViewById(R.id.nextButton2);
    }

    public void onclick3(View view){
        Intent nextButton2=new Intent(this,activity_4.class);
        startActivity(nextButton2);
    }

}